library(shiny)
library(fields)
library(tidyverse)

ui <- basicPage(
  
  titlePanel("Point Blank Revolution"),
  
  # Sidebar with a slider input for number of bins 
  h5("M I S S I O N"),
  h6("Play now or load your data in the form below. Click the plot multiple times to identify new points and then click the 'Ready!' button to
      visualize your score. Try to minimize the score with one, two and three points.Try to do it with more than three points. What is happening when increasing
      the number of points?"),
  
  h5("IF YOU WANT TO LOAD YOUR DATA..."),
  h6("Check the box if your data file has a header. Choose a CSV File with at least two numerical columns and then click on the plot. 
     If there are more than two numerical columns the app will use the first two"),
  checkboxInput("header", "Header", TRUE),
  fileInput("file1", "Choose a CSV file and click on the plot",
            multiple = TRUE,
            accept = c(".csv", ".RData", ".text" )),
  hr(),
  actionButton("ready","Ready!"),
  actionButton("reset","Reset!"),
  plotOutput("plot1", click = "plot_click"),
  tableOutput("check"),
  hr(),
  shiny::actionButton(inputId='ab1', label="Submit!", 
                      icon = icon("th"), 
                      onclick ="window.open('https://jacopodiiorio.typeform.com/to/PU9zHY', '_blank')")
)

server <- function(input, output) {
  
  # available data
  mydata <- read.table(file="data/socialdata.csv", sep=',', header=TRUE)
  colnames(mydata) <- c('x','y')
  
  click_saved <- reactiveValues(singleclick = NULL) #no click
  
  # plot is available
  output$plot1 <- renderPlot({
    if(!is.null(input$file1)){
      mydata <- read.table(input$file1$datapath,
                           header = input$header,
                           row.names = NULL,
                           sep = ',')
      mydata <- mydata %>% dplyr::select(where(is.numeric))
      mydata <- mydata[,c(1,2)]
      colnames(mydata) <- c('x','y')
    }
    prova <- dim(mydata)[1]
    plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
  })
  
  # if you click
  observeEvent(eventExpr = input$plot_click, handlerExpr = { 
    click_saved$singleclick <- rbind(click_saved$singleclick, c(input$plot_click[1], input$plot_click[2])) 
    
    if(!is.null(input$file1)){
      mydata <- read.table(input$file1$datapath,
                           header = input$header,
                           row.names = NULL,
                           sep = ',')
      mydata <- mydata %>% dplyr::select(where(is.numeric))
      mydata <- mydata[,c(1,2)]
      colnames(mydata) <- c('x','y')
    }
    
    output$plot1 <- renderPlot({
      plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
      
      points(click_saved$singleclick[,1], click_saved$singleclick[,2], col='red', pch=16)
    })
    
    output$check <- renderTable({
      as.data.frame(matrix(unlist(click_saved$singleclick), ncol=2, byrow=F))
    })
    
  })
  
  
  # if you click ready 
  observeEvent(eventExpr = input$ready, handlerExpr = { 
    
    if(length(click_saved$singleclick)>0){
      if(!is.null(input$file1)){
        mydata <- read.table(input$file1$datapath,
                             header = input$header,
                             row.names = NULL,
                             sep = ',')
        mydata <- mydata %>% dplyr::select(where(is.numeric))
        mydata <- mydata[,c(1,2)]
        colnames(mydata) <- c('x','y')
      }
      # plot with distances and scores
      output$plot1 <- renderPlot({
      
        plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
        points(click_saved$singleclick[,1], click_saved$singleclick[,2], col='red', pch=16)
      
        # calculate the distances and plot
        centroids <- as.data.frame(matrix(unlist(click_saved$singleclick), ncol=2, byrow=F))
        colnames(centroids) <- c('x', 'y')
        mydist <- rdist(centroids, mydata)
        connection <-  apply(mydist, 2, which.min)
        myscore <- NULL
      
        for(k in 1:length(connection)){
          myscore <- rbind(myscore, (mydata[k,] - centroids[connection[k],])^2)
          myline <- rbind(mydata[k,], centroids[connection[k],])
          lines(myline, col='grey60')
        }
      
        mtext(paste("Your score is ", format(round(sum(colSums(myscore))/(dim(mydata)[1]),2), nsmall=1,big.mark = ',')), side=3)
      
      })
      }
    })
  
  # if you click RESET 
  observeEvent(eventExpr = input$reset, handlerExpr = { 
    
    # back no click
    click_saved$singleclick <- list() #niente cliccato
    
    # plot is available
    output$plot1 <- renderPlot({
      if(!is.null(input$file1)){
        mydata <- read.table(input$file1$datapath,
                             header = input$header,
                             row.names = NULL,
                             sep = ',')
        mydata <- mydata %>% dplyr::select(where(is.numeric))
        mydata <- mydata[,c(1,2)]
        colnames(mydata) <- c('x','y')
      }
      plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
    })
    
    output$check <- renderTable({
      as.data.frame(c(NULL, NULL))
    })
    
  })
  
}


shinyApp(ui, server)

