#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(
  
  titlePanel("Dimensions for Descent"),
  
  # Sidebar with a slider input for number of bins 
  h5("M I S S I O N"),
  h6("Play now or load your data in the form below. Click two distinct points of the plot to draw a line. 
     Try to minimize the score using different lines. To create a new line just click on the plot more than twice."),
  
  h5("IF YOU WANT TO LOAD YOUR DATA..."),
  h6("Check the box if your data file has a header. Choose a CSV File with at least two numerical columns and then click on the plot. 
     If there are more than two numerical columns the app will use the first two"),
  checkboxInput("header", "Header", TRUE),
  fileInput("file1", "Choose a CSV file and click on the plot",
            multiple = TRUE,
            accept = c(".csv", ".RData", ".text" )),
  hr(),
  
  plotOutput("plot1", click = "plot_click"),
  textOutput("check"), # not useful
  hr(),
  
  shiny::actionButton(inputId='ab1', label="Submit!", 
                      icon = icon("th"), 
                      onclick ="window.open('https://jacopodiiorio.typeform.com/to/PU9zHY', '_blank')")
  )


# Define server logic required to draw a histogram
server <- function(input, output) {
  
  # available data
  mydata <- read.table(file="data/socialdata.csv", sep=',', header=TRUE)
  colnames(mydata) <- c('x','y')
  click_saved <- reactiveValues(singleclick = NULL) #niente cliccato
  
  # plot is available
  output$plot1 <- renderPlot({
    if(!is.null(input$file1)){
      mydata <- read.table(input$file1$datapath,
                           header = input$header,
                           row.names = NULL,
                           sep = ',')
      mydata <- mydata %>% dplyr::select(where(is.numeric))
      mydata <- mydata[,c(1,2)]
      colnames(mydata) <- c('x','y')
    }
    prova <- dim(mydata)[1]
    plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
  })
  
  # if you click
  observeEvent(eventExpr = input$plot_click, handlerExpr = { 
    
    click_saved$singleclick <- rbind(click_saved$singleclick, c(input$plot_click[1], input$plot_click[2])) 
    if(dim(click_saved$singleclick)[1]>2)
      click_saved$singleclick <- as.data.frame(click_saved$singleclick[dim(click_saved$singleclick)[1],])
    
    if(!is.null(input$file1)){
      mydata <- read.table(input$file1$datapath,
                           header = input$header,
                           row.names = NULL,
                           sep = ',')
      mydata <- mydata %>% dplyr::select(where(is.numeric))
      mydata <- mydata[,c(1,2)]
      colnames(mydata) <- c('x','y')
    }
    
    output$plot1 <- renderPlot({
      plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
      
      
      points(click_saved$singleclick[,1], click_saved$singleclick[,2], col='red', pch=16)
      if(dim(click_saved$singleclick)[1]==2){
        #create line between the two points
        ys <- as.vector(unlist(click_saved$singleclick[,2]))
        xs <- as.vector(unlist(click_saved$singleclick[,1]))
        fit <- lm(ys~xs)
        abline(fit, col='red')
        
        # projections
        proj <- NULL
        seg <- NULL
        myscore <- NULL
        m_perp <- - ( 1 / fit$coefficients[2] )
        #points(mydata$x, proj, col='purple')
        
        # residuals
        myscore <- NULL
        
        for(k in 1:dim(mydata)[1]){
          
          q_perp <- - mydata[k,'x'] * m_perp + mydata[k,'y']
          M <- rbind( c(fit$coefficients[2],-1) , c(m_perp,-1) )
          b <- c( -fit$coefficients[1] , -q_perp )
          
          proj <- rbind(proj, solve(M,b))
          seg <- rbind(seg,rbind(mydata[k,], solve(M,b), c(NA,NA)))
          lines(seg, col='purple')
          points(proj, col='purple')
          myscore <- rbind(myscore,(mydata[k,] - solve(M,b))^2)
        }
        
        mtext(paste("Your score is ",format(round(sum(colSums(myscore))/(dim(mydata)[1]),2), nsmall=1, big.mark=',')), side=3)
        
        output$check <- renderText(paste(" Y = ", format(round(fit$coefficients[2],2),nsmall=1, big.mark=','),"x + ", format(round(fit$coefficients[1],2),nsmall=1, big.mark=',') ))
      }
      
    })
    
  })
  
  
  
  
}

# Run the application 
shinyApp(ui = ui, server = server)

