#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(shiny)
library(tidyverse)
#library(rgl)
#library(Cairo)
#library(png)


# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("Point Blank 2D"),
  
  # Sidebar with a slider input for number of bins 
  h5("M I S S I O N"),
  h6("Play now or load your data in the form below. 
     Click the plot to identify a new point and try to minimize the score."),
  
  h5("IF YOU WANT TO LOAD YOUR DATA..."),
  h6("Check the box if your data file has a header. Choose a CSV File with at least two numerical columns and then click on the plot. 
     If there are more than two numerical columns the app will use the first two"),
  checkboxInput("header", "Header", TRUE),
  fileInput("file1", "Choose a CSV file and click on the plot",
            multiple = TRUE,
            accept = c(".csv", ".RData", ".text" )),

  
  
  hr(),
  
  plotOutput("scatter", click = "identifier_click",
              brush = brushOpts(
              id = "identifier_brush"
              )),

  
  shiny::actionButton(inputId='ab1', label="Submit!", 
                      icon = icon("th"), 
                      onclick ="window.open('https://jacopodiiorio.typeform.com/to/PU9zHY', '_blank')")
)


# Define server logic required to draw a histogram
server <- function(input, output) {


  mydata <- read.table(file="data/socialdata.csv", sep=',', header=TRUE)
  colnames(mydata) <- c('x','y')
  
  output$scatter <- renderPlot({
    
    if(!is.null(input$file1)){
      mydata <- read.table(input$file1$datapath,
                   header = input$header,
                   row.names = NULL,
                   sep = ',')
      
      mydata <- mydata %>% dplyr::select(where(is.numeric))
      mydata <- mydata[,c(1,2)]
      colnames(mydata) <- c('x','y')
    }
    prova <- dim(mydata)[1]
    plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
  })
  
  observeEvent(input$identifier_click, {
    
    if(!is.null(input$file1)){
    mydata <- read.table(input$file1$datapath,
                          header = input$header,
                          row.names = NULL,
                          sep = ',')
    mydata <- mydata %>% dplyr::select(where(is.numeric))
    mydata <- mydata[,c(1,2)]
    colnames(mydata) <- c('x','y')
    }
    
    prova <- dim(mydata)[1]
    x <- as.numeric(input$identifier_click[1])
    y <- as.numeric(input$identifier_click[2])
    mypoint <- as.data.frame(cbind(x,y))
    
    output$scatter <- renderPlot({
 
      
      plot(mydata$x, mydata$y, xlab='x', ylab='y', pch=16, asp=1)
      points(x, y, col='red', pch=16)
      for(k in 1:prova){
        myline <- rbind(mydata[k,], mypoint)
        lines(myline, col='grey60')
      }
      
      myscore <- NULL
      for(i in 1:(prova)){
        myscore <- rbind(myscore,(mydata[i,] - c(x,y))^2)
      }
      mtext(paste("Your score is ", format(round(sum(colSums(myscore))/prova,3),nsmall=1, big.mark=",")), side=3)
      mtext(paste("You dot is in ", format(round(x,2),nsmall=2, big.mark=','), ",", format(round(y,2), nsmall=2, big.mark=',')), side=4)
      
    })
  })
}

# Run the application 
shinyApp(ui = ui, server = server)

